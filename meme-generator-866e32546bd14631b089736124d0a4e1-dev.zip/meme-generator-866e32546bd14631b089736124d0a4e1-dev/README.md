# Meme Generator

- View the rubric for this assessment [here](https://storage.googleapis.com/hatchways.appspot.com/employers/springboard/student_rubrics/Meme%20Generator%20-%20Student%20Guide.pdf)
